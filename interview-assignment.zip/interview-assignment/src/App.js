import React, { Component } from 'react';
import {GlobalApiUrl} from './GlobalApiUrl.js';
import {
    Card, CardBody, Table, Spinner,
    Modal, ModalBody,CardHeader,
} from 'reactstrap';
import SearchInput from './SearchInput.js'

class App extends Component {

    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            show: false,
            characters : [],
            name: '',
            aliases: '',
            gender: '',
            culture: '',
            name: '',
            authors: [],
            numberOfPages: '',
            publisher: '',
            country: '',
            mediaType: '',
            favorites: '',
            default: false,
            SearchInput: {}
        }
        
    }

    fetchData = (url) => {
        fetch(url, { method: 'GET' }).then((response) => {
            return response.json();
        }).then((result) => {
            if(result) {
                var markedItems = localStorage.getItem('favorites');
                if(markedItems) {
                    var parsedItem = JSON.parse(markedItems);
                }
                else {
                    var parsedItem = {};
                }
                 
                this.setState({ characters: result });
                this.state.characters.map((item, index) => {
                    item.isFavorite = parsedItem[index];
                });
                this.setState({ loading: false });
            }
            else {
                this.setState({ loading: false });
            }
        }).catch((error) => {
            this.setState({loading: false});
            console.log('Internal server error, please try again later'); 
        });
    }
    
    fetchCharacters = (search) => {
        this.setState({ loading: true });
        
        const url = (search === '' || search === undefined) ? GlobalApiUrl.charURL : GlobalApiUrl.charURL+'?name='+search; 
        if(search === ''|| search === undefined) {
            this.fetchData(url);
        }
        else {
            if((search !== '' || search !== undefined) && /^[A-Za-z]+$/.test(search)) {
                this.fetchData(url);
            }     
        }   
        
    }
    getCharacterById = (id) => {
        this.setState({ loading: true });
        const url = GlobalApiUrl.charURL+'/'+id;
        fetch(url, { method: 'GET' }).then((response) => {
            return response.json();
        }).then((result) => {
            if(result) {
                console.log(result);
                this.setState({ showChar: true, loading: false, name: result.name, aliases: result.aliases[0], gender: result.gender, culture: result.culture, show: true });
            }
            else {
                this.setState({ loading: false });
            }
        }).catch((error) => {
            this.setState({loading: false});
            console.log('Internal server error, please try again later'); 
        });
    }
    favoriteArr = [];
    favorites = {};
    markFavorite = (characterId) => {
        console.log('characterId: ',characterId,"this.favorites[characterId]: ",this.favorites[characterId]);
        this.favorites[characterId] = !(this.favorites[characterId] ? this.favorites[characterId] : this.state.default);
        var localItem = localStorage.getItem('favorites');        
        if(localItem && localItem != '') {
            localItem = JSON.parse(localItem);
            var finalVal = {...localItem,...this.favorites};
        }
        else {            
            var finalVal = this.favorites;
        }
        console.log('finalVal: ',finalVal);
        var localArray = this.state.characters;
        localArray.map((item, index) => {
            //console.log(characterId, index);
            if(index === characterId) {
                console.log(characterId, index);
                item.isFavorite = finalVal[characterId];
            }
        });
        console.log('localArray: ',localArray);
        this.setState({characters: localArray});
        localStorage.setItem('favorites',JSON.stringify(finalVal));
    };

    getBookId = (item) => {
        this.setState({ loading: true });
        const url = item;
        fetch(url, { method: 'GET' }).then((response) => {
            return response.json();
        }).then((result) => {
            if(result) {
                console.log(result);                
                this.setState({ loading: false,
                showChar: false,
                    show: true,
                    name: result.name,
                    authors: result.authors,
                    numberOfPages: result.numberOfPages,
                    publisher: result.publisher,
                    country: result.country,
                    mediaType: result.mediaType
                });
            }
            else {
                this.setState({ loading: false });
            }
        }).catch((error) => {
            this.setState({loading: false});
            console.log('Internal server error, please try again later'); 
        });
    }
    toggle = () => {
        this.setState({show: !this.state.show});
    }

    componentDidMount = () => {
        this.fetchCharacters();
    }

 
    getData = (val) => {
        this.fetchCharacters(val);
    }
    render() {
        const { searchInput } = this.state;
    return (
        <div>       
            <div>
                {this.state.loading ?
                <div
                style={{display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    width: "100%",
                    height: "100%",
                    position: "fixed",
                    background: "rgba(0,0,0,.5)"                                
                }}
                ><Spinner/></div>
                : false
             }
            <Modal
                isOpen={this.state.show}
                toggle={this.toggle}
                size="sm"
                backdrop="static"
                style={{ maxWidth: "900px" }}
            >
                <ModalBody style={{ padding: "countryData30px" }}>
                    <Card>
                        <CardHeader className="headerTitle">
                            {this.state.showChar? this.state.aliases : this.state.name}
                            <button type="button" className="close" aria-label="Close" style={{ color: 'black' }}>
                                <span aria-hidden="true" onClick={this.toggle}>×</span>
                            </button>
                        </CardHeader>
                        <CardBody>
                            {this.state.showChar ?
                            <Table>
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Aliases</th>
                                        <th>Gender</th>
                                        <th>Culture</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>{this.state.name ? this.state.name : '-'}</td>
                                        <td>{this.state.aliases ? this.state.aliases: '-'}</td>
                                        <td>{this.state.gender ? this.state.gender:'-'}</td>
                                        <td>{this.state.culture ? this.state.culture:'-'}</td>
                                    </tr>
                                </tbody>
                            </Table>
                            :
                            <Table>
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Authors</th>
                                        <th>Total Pages</th>
                                        <th>Publisher</th>
                                        <th>Country</th>
                                        <th>Media Type</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>{this.state.name? this.state.name: '-'}</td>
                                        <td>{this.state.authors ? this.state.authors: '-'}</td>
                                        <td>{this.state.numberOfPages ? this.state.numberOfPages : '-'}</td>
                                        <td>{this.state.publisher ? this.state.publisher: '-'}</td>
                                        <td>{this.state.country ? this.state.country: '-'}</td>
                                        <td>{this.state.mediaType ? this.state.mediaType: '-'}</td>
                                    </tr>
                                </tbody>
                            </Table>
                            }
                        </CardBody>
                    </Card>
                </ModalBody>
            </Modal>
            <SearchInput searchInput={searchInput} sendData={this.getData} />
                <Table>
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Name</th>
                            <th>Character Alias</th>
                            <th>Gender</th>
                            <th>Book</th>
                            <th>BookMark</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                            {this.state.characters && this.state.characters.map((data, key) => {
                                return (
                                <tr key={key}>
                                    <td >{key+1}</td>
                                    <td >{data.name? data.name : '-'}</td>
                                    <td> <a href="javascript:void(0)" style={{textDecorationLine: "underline", cursor: "pointer"}} onClick={() => this.getCharacterById(key+1)}>{data.aliases[0]}</a>
                                    </td>
                                    <td >{data.gender}</td>
                                    <td>
                                    {data.books && data.books.map((item,i) => {
                                        return (<a href="javascript:void(0)" key={i} style={{textDecorationLine: "underline", margin:'0 5px' , cursor:"pointer"}} onClick={() => this.getBookId(item)}> Book {i+1}</a>);
                                    })}
                                        </td>
                                        <td><a href="javascript:void(0)" style={data.isFavorite == true ? {color: "gold", fontSize: "25px", textDecorationLine: "none"} : {color: "gainsboro", fontSize: "25px", textDecorationLine: "none"}} className="star" onClick={() => this.markFavorite(key)} >&#9733;</a></td>
                                    </tr>
                            )
                            })}
                        
                    </tbody>
                </Table>    
            </div>   
        </div>
    );
        }
}
 
export default App;