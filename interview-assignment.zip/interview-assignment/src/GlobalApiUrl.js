
export const GlobalApiUrl =  {
    charURL : "https://www.anapioficeandfire.com/api/characters",
    bookURL : "https://www.anapioficeandfire.com/api/books"
}
  